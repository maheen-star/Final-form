$(function() {

  rome(inline_cal, { time: false });

});